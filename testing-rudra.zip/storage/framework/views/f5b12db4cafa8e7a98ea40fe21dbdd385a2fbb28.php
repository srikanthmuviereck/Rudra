
<div>

    <?php echo $__env->make('modals.payslip-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row">
            <h3 class="text-center text-white bg-primary py-2 rounded">
                Payslip
            </h3>
        </div>

        <?php if(session()->has('payslipMessage')): ?>
            <div class="alert alert-success alert-dismissible px-3 bold">
                <?php echo e(session()->get('payslipMessage')); ?>

                <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
            </div>
        <?php endif; ?>

         <div class="my-3 text-end">
            <button class="btn btn-sm btn-primary px-3" data-bs-toggle="modal" data-bs-target="#addPayslipModal"><i class="fa fa-plus me-1" aria-hidden="true"></i> Add Payslip</button>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('powergrid.payslip-p-g', [])->html();
} elseif ($_instance->childHasBeenRendered('l1717924315-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1717924315-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1717924315-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1717924315-0');
} else {
    $response = \Livewire\Livewire::mount('powergrid.payslip-p-g', []);
    $html = $response->html();
    $_instance->logRenderedChild('l1717924315-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>
</div>

<script>
    window.addEventListener('downloadPdf', event => {
        // alert(event.detail.downloadLink);

        console.log(event.detail.downloadLink);
        var dw = event.detail.downloadLink;
        var name = event.detail.fileName;
        let link = document.createElement("a");
        link.setAttribute('target', '_blank');
        link.download = name;
        link.href = dw;
        link.click();
        link.remove();

    });

    window.addEventListener('editPSEntry', event => {

        $('#editPayslipModal').modal('show');

    });

    window.addEventListener('deletePSEntry', event => {

        $('#deletePayslipModal').modal('show');

    });
</script>
<?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/dashboard/payslip.blade.php ENDPATH**/ ?>