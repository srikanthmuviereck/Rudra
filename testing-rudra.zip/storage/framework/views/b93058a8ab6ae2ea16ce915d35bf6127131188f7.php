<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
		
		<title>Rudra Connect - Admin</title>
		<link rel="icon" type="image/x-icon" href="<?php echo e(asset('index_img/logo.png')); ?>">
        
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo view('livewire-powergrid::assets.styles')->render(); ?>
        <link href="<?php echo e(asset('css/menu.css')); ?>" rel="stylesheet" />
    </head>
<body>
    <?php echo $__env->make('includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <script src="<?php echo e(asset('js/bootstrap5-bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('js/slim.min.js')); ?>"></script>
    <?php echo view('livewire-powergrid::assets.scripts')->render(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    

    <script src="<?php echo e(asset('js/bootstrap-bundle-min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/menu.js')); ?>"></script>
    
</body>
</html>
<?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/layouts/main.blade.php ENDPATH**/ ?>