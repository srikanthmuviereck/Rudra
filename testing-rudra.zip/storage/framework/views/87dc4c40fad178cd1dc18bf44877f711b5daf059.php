

<div>
   
        

        <div class="container">
            <div class="row">
                <h3 class="text-center text-white bg-primary py-2 rounded">
                    Reports
                </h3>
            </div>
    
            <?php if(session()->has('supervisorMessage')): ?>
                <div class="alert alert-success alert-dismissible px-3 bold">
                    <?php echo e(session()->get('supervisorMessage')); ?>

                    <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
            <?php endif; ?>

            


            

                    

                    <div class="row">

                    <form wire:submit.prevent="sbmt_scrtForm">
                        <div class="row py-4">
                            
                                <div class="col-md-4">
                                    <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">From</label><br>
                                    <input type="date" class="form-control mb-1" id="Image" wire:model="sf_date">
                                    <?php $__errorArgs = ['sf_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">To</label><br>
                                    <input type="date" class="form-control mb-1" id="Image" wire:model="st_date">
                                    <?php $__errorArgs = ['st_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Category</label><br>
                                    <select name="" id="" class="form-select mb-1" wire:model="st_cat">
                                        <option value="">--Select--</option>
                                        <option value="client">Client</option>
                                        <option value="operationteam">Operation Team</option>
                                        <option value="all">Security</option>
                                        
                                    </select>
                                    <?php $__errorArgs = ['st_cat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            
                        </div>

                        <div>
                            
                            <button type="submit"  class="btn btn-sm btn-primary px-3 float-end"><i class="fa fa-filter me-1" aria-hidden="true"></i> Filter</button>
                        </div>

                    </form>

                    <div class="my-4">
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('powergrid.reports-p-g', [])->html();
} elseif ($_instance->childHasBeenRendered('l434714572-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l434714572-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l434714572-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l434714572-0');
} else {
    $response = \Livewire\Livewire::mount('powergrid.reports-p-g', []);
    $html = $response->html();
    $_instance->logRenderedChild('l434714572-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    </div>

                </div>
                

                


            
        </div>
    </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    

    
    <?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/dashboard/reports.blade.php ENDPATH**/ ?>