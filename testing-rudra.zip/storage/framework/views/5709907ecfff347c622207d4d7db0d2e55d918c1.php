<div>
   
        <?php echo $__env->make('modals.supervisor-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container">
            <div class="row">
                <h3 class="text-center text-white bg-primary py-2 rounded">
                    Operation Team
                </h3>
            </div>
			
			<?php if(session()->has('dangerMessage')): ?>
				<div class="alert alert-danger alert-dismissible px-3 bold">
					<?php echo e(session()->get('dangerMessage')); ?>

					<button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
				</div>
			<?php endif; ?>
    
            <?php if(session()->has('supervisorMessage')): ?>
                <div class="alert alert-success alert-dismissible px-3 bold">
                    <?php echo e(session()->get('supervisorMessage')); ?>

                    <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
                </div>
            <?php endif; ?>
    
            <div class="my-3 text-end">
                <button type="button"  class="btn btn-sm btn-primary px-3" data-toggle="modal"  data-target="#supervisorTrack"><i class="fa fa-map-marker me-1" aria-hidden="true"></i> Track Team</button>
                <button type="button" class="btn btn-sm btn-primary px-3" data-toggle="modal" data-target="#addSupervisorModal"><i class="fa fa-plus me-1" aria-hidden="true"></i> Add Team</button>
            </button>
            </div>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('powergrid.supervisor-p-g', [])->html();
} elseif ($_instance->childHasBeenRendered('l164905706-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l164905706-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l164905706-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l164905706-0');
} else {
    $response = \Livewire\Livewire::mount('powergrid.supervisor-p-g', []);
    $html = $response->html();
    $_instance->logRenderedChild('l164905706-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    
    <script>
		
      window.addEventListener('supervisorEdit', event =>{
            $('#editframesModal').modal('show');
        });
    
        window.addEventListener('supervisorDelete', event =>{
            $('#deletecustomerModal').modal('show');
        });
        window.addEventListener('securityview', event =>{
            $('#securitymodal').modal('show');
        });
    </script>
    
    <?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/dashboard/supervisor.blade.php ENDPATH**/ ?>