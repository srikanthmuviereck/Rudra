
<!-- Modal -->
<div wire:ignore.self class="modal fade" id="viewFTModal" tabindex="-1" aria-labelledby="viewFTModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">

    
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="viewFTModalLabel"> <strong>View Tracking Details</strong> </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" wire:click="closeModal"></button>
        </div>
        <div class="modal-body">

          

            <div class="row g-3">
                <div class="col-md-4">
                    <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Check Uniform</label><br>
                    <input readonly type="text" class="form-control" id="Image" wire:model="check_uniform">
                    <?php $__errorArgs = ['check_uniform'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Meet Client Update</label><br>
                    <input readonly type="text" class="form-control" id="Image" wire:model="meet_client_update">
                    <?php $__errorArgs = ['meet_client_update'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Invoice Status</label><br>
                    <input readonly type="text" class="form-control" id="Image" wire:model="invoice_status">
                    <?php $__errorArgs = ['invoice_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

              </div>

              <div class="row g-3 mt-2">
                <div class="col-md-4">
                    <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Night Check Update</label><br>
                    <input readonly type="text" class="form-control" id="Image" wire:model="night_check_update">
                    <?php $__errorArgs = ['night_check_update'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            
                <div class="col-md-4">
                    <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded"> Current Strength Details</label><br>
                    <input readonly type="text" class="form-control" id="Image" wire:model="current_strength_details">
                    <?php $__errorArgs = ['current_strength_details'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-md-4">
                    <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded"> Post Vacancy</label><br>
                    <input readonly type="text" class="form-control" id="Image" wire:model="post_vacancy">
                    <?php $__errorArgs = ['post_vacancy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

          <div class="row g-3 mt-2">
              <div class="col-md-4">
                  <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Client Feedback</label><br>
                  <input readonly type="text" class="form-control" id="Image" wire:model="client_feedback">
                  <?php $__errorArgs = ['client_feedback'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="col-md-4">
                  <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Day Visit Update</label><br>
                  <input readonly type="text" class="form-control" id="Image" wire:model="day_visit_update">
                  <?php $__errorArgs = ['day_visit_update'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
          
            <div class="col-md-4">
                <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Guards Training</label><br>
                <input readonly type="text" class="form-control" id="Image" wire:model="guards_training">
                <?php $__errorArgs = ['guards_training'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

          </div>
			
			<div class="row g-3 mt-2">
            <div class="col-md-6">

              <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Remarks</label><br>
              <textarea readonly type="text" class="form-control" id="Image" wire:model="notes"></textarea>

            </div>
          </div>

          <div class="row g-3 mt-2">
            <div class="col-md-12">
                <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Guards Images</label><br>
                

                <?php if($guards_images): ?>
                    <div class="row">
                      <?php $__currentLoopData = $guards_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        
                          <div class="col-md-2">
                              <img src="<?php echo e(asset('storage/'.$val)); ?>" width="100" class="m-2">
                              <a class="btn btn-sm btn-success rounded-circle text-sm" type="button" href="<?php echo e(asset('storage/'.$val)); ?>" target="_blank"><i class="fa fa-eye"></i></a>
                          </div>
                        
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
				
				<?php else: ?>
                    <span class="text-danger text-bold">No Images</span>
                  <?php endif; ?>
            </div>
        </div>
            
        </div>

        </div>
        
      </div>
    
  </div>






<div wire:ignore.self class="modal fade" id="deleteFTModal" tabindex="-1" aria-labelledby="deleteFTModalLabel" aria-hidden="true">
  <div class="modal-dialog">

    <form wire:submit.prevent="removeTrackDtls">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="deleteFTModalLabel"> <strong>Delete Tracking Details</strong> </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" wire:click="closeModal"></button>
        </div>
        <div class="modal-body">

          <input wire:model="trackid" type="hidden" name=""  id="">

          Do You Want to Delete this Entry...?
            
        </div>

        
        <div class="modal-footer">
          <button type="submit" class="btn btn-danger px-4"> Delete</button>
        </div>
      </div>
    </form>
  </div>
</div>   <?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/modals/fieldtracking-modal.blade.php ENDPATH**/ ?>