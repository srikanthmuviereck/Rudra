<div>

    
    
    <div class="container">

       
       <div class="row">
            <h3 class="text-center text-white bg-primary py-2 rounded">
            Other Settings
            </h3>
        </div>

        <?php if(session()->has('settingMessage')): ?>
            <div class="alert alert-success alert-dismissible px-3 bold">
                <?php echo e(session()->get('settingMessage')); ?>

                <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
            </div>
        <?php endif; ?>
         <div  class="row">
                    <div class="col-md-12">
                            
                        <label for="Image" class="fw-normal d-inline-block bg-primary px-4 py-1 text-white rounded"> <i class="fa fa-cog me-1"></i>Contact US</label><br>
                        <form wire:submit.prevent="updContactUS">

                            <div class="row">
                                <div class="col-md-4">
                                    <label for="" class="fw-normal"><i class="fa fa-phone fw-bolder" aria-hidden="true"></i>
                                        Phone</label> <br> 
                                    <input wire:model.lazy="mobile" type="tel" name="" id="" class="form-control">

                                    <br>
                                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger fw-normal"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="fw-normal"><i class="fa fa-whatsapp  fw-bolder" aria-hidden="true"></i>
                                        Whatsapp</label> <br>
                                    <input wire:model.lazy="whatsapp" type="tel" name="" id="" class="form-control" required>
                                    
                                    <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="fw-normal"><i class="fa fa-envelope-o  fw-bolder" aria-hidden="true"></i>
                                        EMail</label> <br>
                                    <input wire:model.lazy="mail" type="emal" name="" id="" class="form-control" required>
                                    <?php $__errorArgs = ['mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger fw-normal"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary px-4 my-4 float-end">Submit</button>
                        </form>

                    </div>
                    
                </div>
</div></div>
<?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/dashboard/contactus.blade.php ENDPATH**/ ?>