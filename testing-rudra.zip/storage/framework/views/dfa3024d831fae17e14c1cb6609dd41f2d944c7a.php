<div>

    <?php echo $__env->make('modals.notify-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row">
            <h3 class="text-center text-white bg-primary py-2 rounded">
                Notifications
            </h3>
        </div>

        <?php if(session()->has('notifyMessage')): ?>
            <div class="alert alert-success alert-dismissible px-3 bold">
                <?php echo e(session()->get('notifyMessage')); ?>

                <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
            </div>
        <?php endif; ?>

        <div class="my-3 text-end">
            <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#notificationModal"><i class="fa fa-paper-plane me-2" aria-hidden="true"></i> Send Notification</button>
        </div>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('powergrid.notification-p-g', [])->html();
} elseif ($_instance->childHasBeenRendered('l4105431609-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4105431609-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4105431609-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4105431609-0');
} else {
    $response = \Livewire\Livewire::mount('powergrid.notification-p-g', []);
    $html = $response->html();
    $_instance->logRenderedChild('l4105431609-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


    </div>
</div>

<script>
    window.addEventListener('notifyDelete', event => {
        $('#deletenotify').modal('show');
    })
</script><?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/dashboard/notification.blade.php ENDPATH**/ ?>