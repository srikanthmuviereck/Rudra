<div class="d-flex align-items-center" style="padding-left: 10px;">
    <div wire:loading class="spinner-border" role="status" style="color: #656363;">
        <span class="visually-hidden">Loading...</span>
    </div>
</div>
<?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/vendor/livewire-powergrid/components/frameworks/bootstrap5/header/loading.blade.php ENDPATH**/ ?>