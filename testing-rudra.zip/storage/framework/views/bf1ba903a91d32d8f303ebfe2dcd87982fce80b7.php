


<div>

    

    

    <div wire:ignore.self class="modal fade " id="deleteAttModal" tabindex="-1" aria-labelledby="deleteAttModalLabel" aria-hidden="true">
        <div class="modal-dialog">
    
          <form wire:submit.prevent="removeAttendance">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="deleteAttModalLabel"> <strong>Delete Attendance</strong> </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" wire:click="closeModal"></button>
                </div>
                <div class="modal-body px-4">
        
                <input wire:model="att_id" type="hidden" name=""  id="">
        
                Do you want to delete this Attendance Entry ...?
        
                </div>
                <div class="modal-footer">
                <button type="submit" class="btn btn-danger px-4 py-1">Delete</button>
                </div>
            </div>
            </form>
        </div>
    </div>

    

    <div class="container">
        <div class="row mb-4">
            <h3 class="text-center text-white bg-primary py-2 rounded">
                Attendance
            </h3>
        </div>

        <?php if(session()->has('attendanceMessage')): ?>
            <div class="alert alert-success alert-dismissible px-3 bold">
                <?php echo e(session()->get('attendanceMessage')); ?>

                <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
            </div>
        <?php endif; ?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('powergrid.attendance-p-g', [])->html();
} elseif ($_instance->childHasBeenRendered('l281169870-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l281169870-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l281169870-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l281169870-0');
} else {
    $response = \Livewire\Livewire::mount('powergrid.attendance-p-g', []);
    $html = $response->html();
    $_instance->logRenderedChild('l281169870-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>

</div>


<script>
    window.addEventListener('attendanceDelete', event =>{
        $('#deleteAttModal').modal('show');
    });
</script><?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/dashboard/attendance.blade.php ENDPATH**/ ?>