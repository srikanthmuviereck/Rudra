<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <title>Rudra Connect - Login</title>
		<link rel="icon" type="image/x-icon" href="<?php echo e(asset('index_img/logo.png')); ?>">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
    </head>
<body>
    <div id="center-content" >
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/layouts/login.blade.php ENDPATH**/ ?>