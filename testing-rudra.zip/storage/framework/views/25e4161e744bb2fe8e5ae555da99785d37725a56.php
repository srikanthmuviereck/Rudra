<!-- Modal -->
<div wire:ignore.self class="modal fade " id="editadminuser" tabindex="-1" aria-labelledby="editadminuserLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable ">

    <form wire:submit.prevent="updateAdminUser">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editadminuserLabel"> <strong>Edit Admin User</strong> </h5>
        <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-label="Close" wire:click="closeModal"></button>
      </div>
      <div class="modal-body">

        <input type="hidden" name="" id="" wire:model="admin_id">

          <div class="row g-3">
              
              <div class="col-md-12">
                <label for="admin_mail" class="form-label bg-primary px-4 py-1 rounded fw-normal text-white">Email</label>
                <input type="text" name="" id="" class="form-control" id="admin_mail" wire:model="admin_mail">
                <?php $__errorArgs = ['admin_mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger fw-bold"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

              </div>

              <div class="col-md-12">
                <label for="admin_pass" class="form-label bg-primary px-4 py-1 rounded fw-normal text-white">Password</label>
                <input type="text" name="" placeholder="You Can Change the password..." id="" class="form-control" id="admin_pass" wire:model="admin_pass">
                <?php $__errorArgs = ['admin_pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger fw-bold"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>

              <div class="col-md-12">
                <label for="admin_super" class="form-label bg-primary px-4 py-1 rounded fw-normal text-white">Super Admin Access</label>

                <select name="" id="" class="form-select" wire:model="admin_super">
                  <option value="" selected disabled>--Select--</option>
                  <option value="1">Yes</option>
                  <option value="0">No</option>
                </select>
                
                <?php $__errorArgs = ['admin_super'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger fw-bold"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              
          </div>

      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary px-4 py-1"> Update</button>
      </div>
    </div>
  </form>
  </div>
</div>






 
<div wire:ignore.self class="modal fade " id="deleteadminuser" tabindex="-1" aria-labelledby="deleteadminuserLabel" aria-hidden="true">
  <div class="modal-dialog">

    <form wire:submit.prevent="removeAdminUser">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteadminuserLabel"> <strong>Delete Admin User</strong> </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" wire:click="closeModal"></button>
      </div>
      <div class="modal-body px-4">

        <input type="hidden" name="" wire:model="admin_id" id="">

        Do you want to delete this User...?

      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-danger px-4 py-1">Delete</button>
      </div>
    </div>
  </form>
  </div>
</div> <?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/modals/settings-modal.blade.php ENDPATH**/ ?>