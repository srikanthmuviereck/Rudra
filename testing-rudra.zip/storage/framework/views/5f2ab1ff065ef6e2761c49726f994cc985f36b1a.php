<title>Rudhra Connect - Dashboard</title>

<div>

    <div class="container">
        <?php if(session()->has('login_success')): ?>
            <div class="alert alert-success alert-dismissible px-3 bold">
                <?php echo e(session()->get('login_success')); ?>

                <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
            </div>
        <?php endif; ?>
        <div class="row my-3">
            <div class="col-md-4 mt-3">
                <div class="card border-end rounded" style="border: 0 !important; border-left: 5px solid rgb(0, 102, 255) !important;border-radius: 15px !important; box-shadow: 2px 3px 10px rgb(226, 226, 226) !important;">
                    <div class="card-body">

                        <div class="row">

                        <div class="col-md-4">

                            <h2 class="card-title fw-bolder fs-1" style="color: rgb(0, 102, 255);"><i class="fa fa-users" style="font-size: 40px !important;" aria-hidden="true"></i></h2>
                            <p class="card-text fw-bold">Security</p>

                        </div>

                        <div class="col-md-8 text-end">

                            <h2 class="h2 me-2"><?php echo e($count_security); ?></h2>
                        <a href="securities" class="btn btn-primary btn-sm rounded-pill px-4">View Entire Details</a>

                        </div>
                    </div>
                        
                        
                    </div>
                </div>
            </div>
            <div class="col-md-4 mt-3">
                <div class="card border-end rounded" style="border: 0 !important; border-left: 5px solid rgb(0, 102, 255) !important;border-radius: 15px !important; box-shadow: 2px 3px 10px rgb(226, 226, 226) !important;">
                    <div class="card-body">

                        <div class="row">

                        <div class="col-md-4">

                            <h2 class="card-title fw-bolder fs-1" style="color: rgb(0, 102, 255);"><i class="fa fa-users" style="font-size: 40px !important;" aria-hidden="true"></i></h2>
                            <p class="card-text fw-bold">Teams</p>

                        </div>

                        <div class="col-md-8 text-end">

                            <h2 class="h2 me-2"><?php echo e($count_supervisor); ?></h2>
                        <a href="supervisor" class="btn btn-primary btn-sm rounded-pill px-4">View Entire Details</a>

                        </div>
                    </div>
                        
                        
                    </div>
                </div>
            </div>
            <div class="col-md-4 mt-3">
                <div class="card border-end rounded" style="border: 0 !important; border-left: 5px solid rgb(0, 102, 255) !important;border-radius: 15px !important; box-shadow: 2px 3px 10px rgb(226, 226, 226) !important;">
                    <div class="card-body">

                        <div class="row">

                        <div class="col-md-4">

                            <h2 class="card-title fw-bolder fs-1" style="color: rgb(0, 102, 255);"><i class="fa fa-users" style="font-size: 40px !important;" aria-hidden="true"></i></h2>
                            <p class="card-text fw-bold">Clients</p>

                        </div>

                        <div class="col-md-8 text-end">

                            <h2 class="h2 me-2"><?php echo e($count_client); ?></h2>
                        <a href="client" class="btn btn-primary btn-sm rounded-pill px-4">View Entire Details</a>

                        </div>
                    </div>
                        
                        
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-md-6 py-3 rounded">
                <h4 class="h6  text-center bg-primary text-white py-2 rounded">Recent Securities</h4>

                <div class="table-responsive">
                    <table class="table mt-3">
                        <thead>
                            <tr>
                                <th>RCS EMP ID</th>
                                <th>Security Name</th>
                                <th>Mobile</th>
                            </tr>
                        </thead>
                        <tbody>
    
                            <?php $__currentLoopData = $security; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scrt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($scrt->scrt_id); ?></td>
                                    <td><?php echo e($scrt->name); ?></td>
                                    <td><?php echo e($scrt->mobile); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>

            <div class="col-md-6 py-3 rounded">
                <h4 class="h6  text-center bg-primary text-white py-2 rounded">Recent Operation Teams</h4>
                <div class="table-responsive">
                    <table class="table mt-3">
                        <thead>
                            <tr>
                                <th>RCS EMP ID</th>
                                <th>Name</th>
                                <th>Mobile</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $supervisor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spvr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($spvr->spvr_id); ?></td>
                                    <td><?php echo e($spvr->name); ?></td>
                                    <td><?php echo e($spvr->mobile); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
                        
        </div>

        <div class="row mt-5">
            <div class="col-md-6 py-3 rounded">
                <h4 class="h6  text-center bg-primary text-white py-2 rounded">Recent Clients</h4>

                <div class="table-responsive">
                    <table class="table mt-3">
                        <thead>
                            <tr>
                                <th>Client ID</th>
                                <th>Client Name</th>
                                <th>Mobile</th>
                            </tr>
                        </thead>
                        <tbody>
    
                            <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clnt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($clnt->clnt_id); ?></td>
                                    <td><?php echo e($clnt->c_name); ?></td>
                                    <td><?php echo e($clnt->mobile); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
            </div>
                        
        </div>

        
    </div>
</div><?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/dashboard/admin-dashboard.blade.php ENDPATH**/ ?>