<div>

    <section class="mt-5 " >
        <div class="container ">
          <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-12 col-md-8 col-lg-6 col-xl-5">
              <div class="card shadow-lg" style="border: 0 !important;border-radius: 1rem;">
                <div class="card-body p-5">

                  <div class="text-center mb-4">
                    <img src="<?php echo e(asset('index_img/logo.png')); ?>" alt="" width="150">
                  </div>
                

                  <?php $__errorArgs = ['login_error'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error text-center mt-2" role="alert">
                      <strong><?php echo e($message); ?></strong><br/><br/>
                    </span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                  <form method="post" wire:submit.prevent="submit">
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Email</label>
                      <input type="email" class="form-control" wire:model="email" id="exampleInputEmail1" aria-describedby="emailHelp">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error" role="alert">
                    <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-4">
                      <label for="loginpassword" class="form-label">Password</label>
                      <input type="password" class="form-control" wire:model="password" id="loginpassword">
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="error" role="alert">
                        <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="text-center mt-2">
    
                        <button type="submit" wire:click.prevent='submit' class="btn btn-primary btn-block px-5 py-2 rounded-pill"><i class="fa fa-sign-in me-1" aria-hidden="true"></i> Login</button>
    
                    </div>

                  
                    
                  </form>
        
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    
</div>
<?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/login/login-form.blade.php ENDPATH**/ ?>