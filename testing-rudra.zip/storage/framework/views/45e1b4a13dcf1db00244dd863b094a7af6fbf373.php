<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo \Livewire\Livewire::styles(); ?>

<link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet">


<link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('js/jquery-3.3.1.js')); ?>" ></script>
<script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>


 <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.js"></script>
 


 


<?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/includes/header.blade.php ENDPATH**/ ?>