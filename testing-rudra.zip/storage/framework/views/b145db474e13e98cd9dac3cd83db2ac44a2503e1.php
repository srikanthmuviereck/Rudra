<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Rudhra Connect - Welcome</title>
    </head>

    <body class="antialiased">
        <div style="display: flex; justify-content: center;align-items: center">
            <img src="<?php echo e(asset('index_img/index.jpg')); ?>" width="1000" alt="" >
        </div>
    </body>
</html>
<?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/welcome.blade.php ENDPATH**/ ?>