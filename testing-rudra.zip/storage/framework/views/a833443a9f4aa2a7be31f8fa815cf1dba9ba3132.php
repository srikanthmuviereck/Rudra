<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <title>Rudra Connect - Payslip</title>
    <style>

        body{
            font-family: Arial, Helvetica, sans-serif !important;
            /* letter-spacing: -0.3px; */
        }

        .invoice-wrapper{ margin: auto; }

        table{
            width: 100%;
            border-collapse:collapse;
            border: 1px solid black;
            margin-top: 20px !important;
        }

        table td{line-height:25px;padding-left: 8px;font-size: 14px !important;}

        .companyName{
            font-size: 20px !important;
        }

        .addr{
            font-size: 14px !important;
            font-weight: 700;
        }

    </style>
</head>
<body>
    <div class="row invoice-wrapper">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <center>
                        <h2 class="companyName">
                            RUDRA CORPORATE SERVICES
                        </h2>
                        <p class="addr">
                           D.No: 3-1-104/A, Krishna Nagar, 9th Lane, Sri Venkateswara Nilayam, Guntur - 522 006
                        </p>
                    </center>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table border="1">
                        <tr>
                            <td><strong>Name</strong></td>
                            <td><?php echo e($name); ?></td>
                            <td><strong>Month & Year</strong></td>
                            <td><?php echo e($monthandyear); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Emp. Id</strong></td>
                            <td><?php echo e($empid); ?></td>
                            <td><strong>Client Name</strong></td>
                            <td><?php echo e($clientname); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Designation</strong></td>
                            <td><?php echo e($designation); ?></td>
                            <td><strong>Bank</strong></td>
                            <td><?php echo e($bank); ?></td>
                        </tr>
                        <tr>
                            <td><strong>UAN</strong></td>
                            <td><?php echo e($uan); ?></td>
                            <td><strong>Bank A/C No</strong></td>
                            <td><?php echo e($bankaccno); ?></td>
                        </tr>
                        <tr>
                            <td><strong>ESI No</strong></td>
                            <td><?php echo e($esino); ?></td>
                            <td><strong>Bank IFSC Code</strong></td>
                            <td><?php echo e($bankifsccode); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4" style="padding: 10px 0px;"></td>
                        </tr>
                        <tr>
                            <td><strong>No. of Duties : </strong> <span> <?php echo e($noofduties); ?> </span> </td>
                            <td><strong>OT : </strong> <span> <?php echo e($overtime); ?> </span> </td>
                            <td><strong>Total Working Days : </strong></td>
                            <td><?php echo e($totalworkingdays); ?></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center;font-weight:bold; ">Earnings</td>
                            <td colspan="2" style="text-align: center;font-weight:bold; ">Deduction</td>
                        </tr>
                        <tr>
                            <td><strong>Basic Pay</strong></td>
                            <td><?php echo e($basicpay); ?></td>
                            <td><strong>EPF</strong></td>
                            <td><?php echo e($epf); ?></td>
                        </tr>
                        <tr>
                            <td><strong>DA</strong></td>
                            <td><?php echo e($dapay); ?></td>
                            <td><strong>ESI</strong></td>
                            <td><?php echo e($esi); ?></td>
                        </tr>
                        <tr>
                            <td><strong>OT</strong></td>
                            <td><?php echo e($otpay); ?></td>
                            <td><strong>Uniform Deduction</strong></td>
                            <td><?php echo e($uniformdeduction); ?></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><strong>Advance</strong></td>
                            <td><?php echo e($advance); ?></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td></td>
                            <td><strong>Others</strong></td>
                            <td><?php echo e($others); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Gross Salary</strong></td>
                            <td><?php echo e($totaldeduction); ?></td>
                            <td><strong>Total Deduction</strong></td>
                            <td><?php echo e($gross_salary); ?></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center;font-weight:bold; ">Net Pay</td>
                            <td colspan="2" style="text-align: left;font-weight:bold; "><?php echo e($net_pay); ?></td>
                        </tr>
                        <tr>
                            <td colspan="4">
                                <strong>In Word : </strong> <?php echo e($netpayinwords); ?>  
                            </td>
                        </tr>
                        <tr>
                            <td colspan="4">
                                <strong>
                                    This is a computer-generated pay slip and does not require any further authentication
                                </strong>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>    
</body>
</html><?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/layouts/invoice.blade.php ENDPATH**/ ?>