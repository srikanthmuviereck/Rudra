

<div>

    
    
    <div class="container">

        <?php echo $__env->make('modals.settings-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <h3 class="text-center text-white bg-primary py-2 rounded">
                Admin Settings
            </h3>
        </div>

        <?php if(session()->has('settingMessage')): ?>
            <div class="alert alert-success alert-dismissible px-3 bold">
                <?php echo e(session()->get('settingMessage')); ?>

                <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
            </div>
        <?php endif; ?>

        <div class="row">
            <ul class="nav nav-tabs nav-fill" id="myTab">
                <li class="nav-item">
                    <a href="#tandc" class="nav-link <?php echo e($tab == 'tandc' ? 'active' : ''); ?>" wire:click="$set('tab', 'tandc')" data-bs-toggle="tab">Terms & Conditions</a>
                </li>
                <li class="nav-item">
                    <a href="#pp" class="nav-link <?php echo e($tab == 'pp' ? 'active' : ''); ?>" wire:click="$set('tab', 'pp')" data-bs-toggle="tab">Privacy Policy</a>
                </li>

                <li class="nav-item">
                    <a href="#abt_us" class="nav-link <?php echo e($tab == 'abt_us' ? 'active' : ''); ?>" wire:click="$set('tab', 'abt_us')" data-bs-toggle="tab">About US</a>
                </li>

                <li class="nav-item" wire:click="getDtl">
                    <a href="#cus" class="nav-link <?php echo e($tab == 'cus' ? 'active' : ''); ?>" wire:click="$set('tab', 'cus')" data-bs-toggle="tab">Others</a>
                </li>
            </ul>
        </div>

        <div class="tab-content mt-3">

            <div wire:ignore class="tab-pane fade show active mb-5" id="tandc">
 
                <div class="p-4 mt-4">
                    <form wire:submit.prevent="updTerms">
        
                        <div class="col-md-12">
                            <label for="Image" class="fw-normal d-inline-block bg-primary px-4 py-1 text-white rounded">Terms and Conditions</label><br>
        
                            <?php $__currentLoopData = $get_terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $terms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <textarea wire:model.lazy="terms" class="form-control " name="terms" id="terms" style="height:300px;"><?php echo e($terms->value); ?></textarea>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                            <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
                        </div>
        
                        <button type="submit" class="btn btn-primary px-4 my-3 float-end">Submit</button>
        
                    </form>
                </div>
    
            </div>

            <div wire:ignore class="tab-pane fade  mb-5" id='pp'>

                <div class="p-4 mt-4">

                    <form wire:submit.prevent="updPrivacy">
                
                        <div class="col-md-12">
            
                            <label for="Image" class="fw-normal d-inline-block bg-primary px-4 py-1 text-white rounded">Privacy Policy</label><br>
                            <?php $__currentLoopData = $get_privacy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $privacy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <textarea wire:model="privacy" class="form-control required" name="privacy" id="privacy" style="height:300px;"><?php echo e($privacy->value); ?></textarea>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
            
                    
                        <button type="submit" class="btn btn-primary px-4 my-3 float-end">Submit</button>
                    </form>

                </div>
            </div>

            <div wire:ignore class="tab-pane fade  mb-5" id='abt_us'>

                <div class="p-4 mt-4">

                    <form wire:submit.prevent="updAbout">
                
                        <div class="col-md-12">
            
                            <label for="Image" class="fw-normal d-inline-block bg-primary px-4 py-1 text-white rounded">About US</label><br>
                            <?php $__currentLoopData = $get_about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <textarea wire:model="abt" class="form-control required" name="abt" id="abt" style="height:300px;"><?php echo e($abt->value); ?></textarea>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
            
                    
                        <button type="submit" class="btn btn-primary px-4 my-3 float-end">Submit</button>
                    </form>

                </div>
            </div>

            <div wire:ignore class="tab-pane fade  mb-5" id='cus'>

               <!--  <div  class="row">
                    <div class="col-md-12">
                            
                        <label for="Image" class="fw-normal d-inline-block bg-primary px-4 py-1 text-white rounded"> <i class="fa fa-cog me-1"></i>Contact US</label><br>
                        <form wire:submit.prevent="updContactUS">

                            <div class="row">
                                <div class="col-md-4">
                                    <label for="" class="fw-normal"><i class="fa fa-phone fw-bolder" aria-hidden="true"></i>
                                        Phone</label> <br> 
                                    <input wire:model.lazy="c_mble" type="tel" name="" id="" class="form-control">

                                    <br>
                                    <?php $__errorArgs = ['c_mble'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger fw-normal"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="fw-normal"><i class="fa fa-whatsapp  fw-bolder" aria-hidden="true"></i>
                                        Whatsapp</label> <br>
                                    <input wire:model.lazy="c_wapp" type="tel" name="" id="" class="form-control" required>
                                    
                                    <?php $__errorArgs = ['c_wapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-4">
                                    <label for="" class="fw-normal"><i class="fa fa-envelope-o  fw-bolder" aria-hidden="true"></i>
                                        EMail</label> <br>
                                    <input wire:model.lazy="c_mail" type="emal" name="" id="" class="form-control" required>
                                    <?php $__errorArgs = ['c_mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger fw-normal"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary px-4 my-4 float-end">Submit</button>
                        </form>

                    </div> -->
                    
                </div>

                <?php
                
                $get_super = 0;

                foreach($chk_super as $sup){
                    $get_super = $sup->superuser;
                }
                
                ?>

                <?php if($get_super == 1): ?>

                <div class="row border p-3 mt-4">

                    <div wire:ignore class="col-md-12">

                        <div class="my-3">

                            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded"> <i class="fa fa-cog me-1"></i>Admin Users</label>

                            <button class="btn btn-sm px-4 btn-primary float-end" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample"><i class="fa fa-plus me-1" aria-hidden="true"></i> Add User</button>

                        </div>

                        <div class="collapse my-3" id="collapseExample">
                            <div class="card card-body">
                                <form wire:submit.prevent="InsUser">
                                    <div class="row">

                                        <label for="" class="">Add User</label>
                                        <div class="col-md-4 p-2">
                                            <input wire:model="admin_email_new" type="email" name="" id="" class="form-control" placeholder="Enter Email..." required>
                                        </div>
                                        <div class="col-md-4 p-2">
                                            <input wire:model="admin_pass_new" type="text" name="" id="" class="form-control" placeholder="Enter Password..." required>
                                        </div>
                                        <div class="col-md-4 p-2">
                                            <button type="submit" class="btn btn-primary px-4">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="table-responsive">
                            <table class="table">

                                <thead class="bg-primary text-white">
                                    <tr>
                                        <th>S.No</th>
                                        <th>Email</th>
                                        <th>Super User</th>
                                        <th>Created At</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>

                                    <?php $tmpid = 1;?>

                                <?php $__currentLoopData = $get_admin_dtl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <td class="align-middle"><?php echo e($tmpid); ?></td>
                                        <td class="align-middle"><?php echo e($dtl->email); ?>


                                            <?php if(session()->get('authMail') == $dtl->email): ?>

                                            <i class="ms-2 text-success fa fa-check" title="Active User" aria-hidden="true"></i>

                                            <?php endif; ?>
                                        
                                        </td>
                                        <td class="align-middle"><?php echo e(($dtl->superuser == 1)?'Yes':'No'); ?></td>
                                        <td class="align-middle"><?php echo e($dtl->created_at); ?></td>
                                        <td class="align-middle"><button type="button"  class="btn btn-sm btn-primary rounded" data-bs-toggle="modal" data-bs-target="#editadminuser" wire:click='editAdminUser(<?php echo e($dtl->id); ?>)'><i class="fa fa-pencil"></i></button>
                                            <button  type="button" class="btn btn-sm btn-danger rounded" data-bs-toggle="modal" data-bs-target="#deleteadminuser" wire:click='deleteAdminUser(<?php echo e($dtl->id); ?>)'><i class="fa fa-times"></i></button></td>
                                    </tr>

                                    <?php $tmpid++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>

                        
                    </div>
                </div>

                <?php endif; ?>
            </div>
        </div>
       
    </div>
</div>

<script src="https://cdn.ckeditor.com/ckeditor5/27.1.0/classic/ckeditor.js"></script>

<script>
     ClassicEditor
       .create(document.querySelector('#terms'))
       .then(editor => {
           editor.model.document.on('change:data', () => {
           window.livewire.find('<?php echo e($_instance->id); ?>').set('terms', editor.getData());
          })
       });


    ClassicEditor
       .create(document.querySelector('#privacy'))
       .then(editor => {
           editor.model.document.on('change:data', () => {
           window.livewire.find('<?php echo e($_instance->id); ?>').set('privacy', editor.getData());
          })
       });

    ClassicEditor
       .create(document.querySelector('#abt'))
       .then(editor => {
           editor.model.document.on('change:data', () => {
           window.livewire.find('<?php echo e($_instance->id); ?>').set('abt', editor.getData());
          })
       });
       
</script>
<?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/dashboard/settings.blade.php ENDPATH**/ ?>