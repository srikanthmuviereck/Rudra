<div>

    <?php echo $__env->make('modals.fieldtracking-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row">
            <h3 class="text-center text-white bg-primary py-2 rounded">
                Field Tracking
            </h3>
        </div>

        <?php if(session()->has('ftMessage')): ?>
            <div class="alert alert-success alert-dismissible px-3 bold">
                <?php echo e(session()->get('ftMessage')); ?>

                <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
            </div>
        <?php endif; ?>

        <div class="my-3 text-end">
            
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('powergrid.fieldtracking-p-g', [])->html();
} elseif ($_instance->childHasBeenRendered('l2153134300-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2153134300-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2153134300-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2153134300-0');
} else {
    $response = \Livewire\Livewire::mount('powergrid.fieldtracking-p-g', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2153134300-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<script>
    window.addEventListener('viewTrackDetails', event => {
        $('#viewFTModal').modal('show');
    });

    window.addEventListener('deleteTrackDetails', event => {
        $('#deleteFTModal').modal('show');
    });

</script><?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/dashboard/fieldtracking.blade.php ENDPATH**/ ?>