
<div>

    <?php echo $__env->make('modals.clients-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="row">
            <h3 class="text-center text-white bg-primary py-2 rounded">
                Client
            </h3>
        </div>
		
		<?php if(session()->has('dangerMessage')): ?>
            <div class="alert alert-danger alert-dismissible px-3 bold">
                <?php echo e(session()->get('dangerMessage')); ?>

                <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
            </div>
        <?php endif; ?>

        <?php if(session()->has('clientMessage')): ?>
            <div class="alert alert-success alert-dismissible px-3 bold">
                <?php echo e(session()->get('clientMessage')); ?>

                <button class="pull-right btn btn-large pt-0" onclick="this.parentElement.style.display='none';">&times;</button>
            </div>
        <?php endif; ?>

        <div class="my-3 text-end">
            <button class="btn btn-sm btn-primary px-3" data-bs-toggle="modal" data-bs-target="#clientModal"><i class="fa fa-plus me-1" aria-hidden="true"></i> Add Client</button>
        </div>
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('powergrid.client-p-g', [])->html();
} elseif ($_instance->childHasBeenRendered('l2567150148-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2567150148-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2567150148-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2567150148-0');
} else {
    $response = \Livewire\Livewire::mount('powergrid.client-p-g', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2567150148-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>


<script>
    window.addEventListener('clientEditModal', event => {
        $('#editClientModal').modal('show');
    });

    window.addEventListener('clientDeleteModal', event => {
        $('#deleteClientModal').modal('show');
    });
	
	window.addEventListener('securityview', event =>{
        $('#securitymodal').modal('show');
    });
</script><?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/livewire/dashboard/client.blade.php ENDPATH**/ ?>