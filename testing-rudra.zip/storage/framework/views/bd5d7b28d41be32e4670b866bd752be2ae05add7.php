<!-- Modal -->
<div wire:ignore.self class="modal fade" id="addPayslipModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="addPayslipModalLabel" aria-hidden="true">
  
  <div class="modal-dialog modal-xl">

    <form wire:submit.prevent="addPaySlip">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="addPayslipModalLabel"> <strong>Add Payslip</strong> </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" wire:click="closeModal"></button>
        </div>
        <div class="modal-body">

          <div class="row g-3">
            <div class="col-md-4">
              <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Pay Slip For</label><br>

              <select name="" id="" class="form-select"  wire:change="slipforchange()" wire:model.lazy="slipfor">
                <option value="" selected disabled>--Select--</option>
                <option value="scrt">Security</option>
                <option value="spvr">Operation Team</option>
              </select>
              
              <?php $__errorArgs = ['slipfor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
       <!--      <div  class="col-md-4">
                <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded required">Name</label><br>
                
                
                <select  name="" id="" class="form-select"  wire:change="empchange" wire:model.lazy.lazy="name">
                  <option value="" selected disabled>--Select--</option>
                  <?php if(!empty($empdtls)): ?>
                    
                    <?php $__currentLoopData = $empdtls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($dtls->emp_id); ?>"><?php echo e($dtls->name); ?>(<?php echo e($dtls->mobile); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </select>

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> -->
               <div class="col-md-4">
            <label for="name" class="fw-normal bg-primary px-4 py-1 text-white rounded">Name *</label><br>
            <div class="input-group" wire:click.prevent='customer_dropdown1'   wire:keydown.shift='customer_dropdown1'>
                <input type="text" class="form-control cursor-hand" readonly="" value=""  wire:model.lazy='name'>
               
                <span class="input-icon cursor-hand"><i
                    class="fa fa-angle-down"></i></span>
                </div>  
          
          <?php if($dropdown): ?>
          
           <div class="searchable-dropdown" >
                    <div class="sticky bg-white input-group pd-10 col-md-10">
                        <span class="input-icon cursor-hand"><i class="fa fa-search-plus"></i></span>
                        <input type="search" class="form-control" placeholder="Search Securities.."  wire:model.lazy='search_customer1'>
                </div>
                <div class="table">
                  
                    <table class="table table-striped table-bordered">
                        <thead>
                            <th>Select</th>
                        </thead>
                       
                       <?php if(count($empdtls)>0): ?>
                       <?php $__currentLoopData = $empdtls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                   
                    <tr  tabindex="<?php echo e($key); ?>" wire:keydown.enter="<?php echo e($value->name); ?>" wire:click.prevent="customer_selected1('<?php echo e($value->name); ?>', '<?php echo e($value->id); ?>')" class="cursor-hand table-select" ><td><?php echo e($value->name); ?></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endif; ?>
                </table>
                </div>
                    <div class="footer-fixed">
                        <button type="button" class="btn btn-sm btn-danger btn-round close mx-auto text-center d-block" wire:click.lazy='customer_dropdown1'><i class="fa fa-close"></i> Close</button>
                    </div>
                </div>
          
          <?php endif; ?>
            
            
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
        </div>
            <div class="col-md-4">
              <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Month & Year</label><br>
              <input type="month" class="form-control" id="Image" wire:model.lazy="monthandyear">
              <?php $__errorArgs = ['monthandyear'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
			<div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Designation</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="designation" readonly>
            <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">UAN</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="uan">
            <?php $__errorArgs = ['uan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">ESI No</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="esino">
            <?php $__errorArgs = ['esino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          
        </div>

        <div class="row g-3 mt-2">
          
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Bank</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="bank" readonly>
            <?php $__errorArgs = ['bank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Bank A/C No</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="bankaccno" readonly>
            <?php $__errorArgs = ['bankaccno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
			<div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Bank IFSC Code</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="bankifsccode" readonly>
            <?php $__errorArgs = ['bankifsccode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
			<div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Client Name</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="clientname">
            <?php $__errorArgs = ['clientname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
			<div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Client Location</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="clientloc">
            <?php $__errorArgs = ['clientloc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded required">No. of Duties</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="noofduties">
            <?php $__errorArgs = ['noofduties'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded required">Over Time (OT)</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="overtime">
            <?php $__errorArgs = ['overtime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded required">Total Working Days</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="totalworkingdays">
            <?php $__errorArgs = ['totalworkingdays'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded required">Basic Pay</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="basicpay">
            <?php $__errorArgs = ['basicpay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">DA</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="dapay">
            <?php $__errorArgs = ['dapay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">OT Pay</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="otpay">
            <?php $__errorArgs = ['otpay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">EPF</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="epf">
            <?php $__errorArgs = ['epf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">ESI</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="esi">
            <?php $__errorArgs = ['esi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Uniform Deduction</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="uniformdeduction">
            <?php $__errorArgs = ['uniformdeduction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Advance</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="advance">
            <?php $__errorArgs = ['advance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Others</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="others">
            <?php $__errorArgs = ['others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Gross Salary</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="gross_salary">
            <?php $__errorArgs = ['gross_salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Total Deduction</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="totaldeduction">
            <?php $__errorArgs = ['totaldeduction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded required">Net Pay</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="net_pay">
            <?php $__errorArgs = ['net_pay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary btn-sm px-4"><i class="fa fa-plus me-1" aria-hidden="true"></i> Add</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Edit Modal -->

<div wire:ignore.self class="modal fade" id="editPayslipModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="editPayslipModalLabel" aria-hidden="true">
  
  <div class="modal-dialog modal-xl">

    <form wire:submit.prevent="updPaySlip">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="editPayslipModalLabel"> <strong>Add Payslip</strong> </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" wire:click="closeModal"></button>
        </div>
        <div class="modal-body">
<input wire:model.lazy="psId" type="hidden" name=""  id="">
          <div class="row g-3">
            <div class="col-md-4">
              <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Pay Slip For</label><br>

              <select name="" id="" class="form-select"  wire:change="slipforchange()" wire:model.lazy="slipfor">
                <option value="" selected disabled>--Select--</option>
                <option value="scrt">Security</option>
                <option value="spvr">Supervisor</option>
              </select>
              
              <?php $__errorArgs = ['slipfor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div  class="col-md-4">
                <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Name</label><br>
                
                
                <select  name="" id="" class="form-select"  wire:change="empchange" wire:model.lazy.lazy="name">
                  <option value="" selected disabled>--Select--</option>
                  <?php if(!empty($empdtls)): ?>
                    
                    <?php $__currentLoopData = $empdtls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($dtls->emp_id); ?>"><?php echo e($dtls->name); ?>(<?php echo e($dtls->mobile); ?>)</option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </select>

                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-4">
              <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Month & Year</label><br>
              <input type="month" class="form-control" id="Image" wire:model.lazy="monthandyear">
              <?php $__errorArgs = ['monthandyear'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
			<div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Designation</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="designation" readonly>
            <?php $__errorArgs = ['designation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">UAN</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="uan">
            <?php $__errorArgs = ['uan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">ESI No</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="esino">
            <?php $__errorArgs = ['esino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          
        </div>

        <div class="row g-3 mt-2">
          
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Bank</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="bank" readonly>
            <?php $__errorArgs = ['bank'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Bank A/C No</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="bankaccno" readonly>
            <?php $__errorArgs = ['bankaccno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
			<div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Bank IFSC Code</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="bankifsccode" readonly>
            <?php $__errorArgs = ['bankifsccode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
			<div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Client Name</label><br>
            <input type="text" class="form-control" id="Image" wire:model.lazy="clientname">
            <?php $__errorArgs = ['clientname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded required">No. of Duties</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="noofduties">
            <?php $__errorArgs = ['noofduties'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded required">Over Time (OT)</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="overtime">
            <?php $__errorArgs = ['overtime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded required">Total Working Days</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="totalworkingdays">
            <?php $__errorArgs = ['totalworkingdays'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded required">Basic Pay</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="basicpay">
            <?php $__errorArgs = ['basicpay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">DA</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="dapay">
            <?php $__errorArgs = ['dapay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">OT Pay</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="otpay">
            <?php $__errorArgs = ['otpay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">EPF</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="epf">
            <?php $__errorArgs = ['epf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">ESI</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="esi">
            <?php $__errorArgs = ['esi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Uniform Deduction</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="uniformdeduction">
            <?php $__errorArgs = ['uniformdeduction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Advance</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="advance">
            <?php $__errorArgs = ['advance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Others</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="others">
            <?php $__errorArgs = ['others'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded">Gross Salary</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="gross_salary">
            <?php $__errorArgs = ['gross_salary'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-4">
            <label for="Image" class="fw-normal bg-primary px-4 py-1 text-white rounded">Total Deduction</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="totaldeduction">
            <?php $__errorArgs = ['totaldeduction'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="col-md-4">
            <label for="Image" class="fw-normal  bg-primary px-4 py-1 text-white rounded required">Net Pay</label><br>
            <input type="number" class="form-control" id="Image" wire:model.lazy="net_pay">
            <?php $__errorArgs = ['net_pay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        </div>
        <div class="modal-footer">
          <button type="submit" class="btn btn-primary btn-sm px-4"><i class="fa fa-plus me-1" aria-hidden="true"></i> Update</button>
        </div>
      </div>
    </form>
  </div>
</div>





<div wire:ignore.self class="modal fade " id="deletePayslipModal" tabindex="-1" aria-labelledby="deletePayslipModalLabel" aria-hidden="true">
  <div class="modal-dialog">

    <form wire:submit.prevent="removePayslip">
      <div class="modal-content">
          <div class="modal-header">
          <h5 class="modal-title" id="deletePayslipModalLabel"> <strong>Delete Enrty</strong> </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" wire:click="closeModal"></button>
          </div>
          <div class="modal-body px-4">
  
            <input wire:model.lazy="psId" type="hidden" name=""  id="">
    
            Do you want to delete this Entry ...?
  
          </div>
          <div class="modal-footer">
          <button type="submit" class="btn btn-danger px-4 py-1">Delete</button>
          </div>
      </div>
      </form>
  </div>
</div>

<script>
  $(document).ready(function(){

    var inputs = document.getElementsByTagName('input');

    inputs.autocomplete = "off";

  });
</script>
<?php /**PATH /var/www/vhosts/yetloapps.com/rudhra.yetloapps.com/resources/views/modals/payslip-modal.blade.php ENDPATH**/ ?>