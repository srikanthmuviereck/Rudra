<?php

namespace App\Models\Tables;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class supervisorModel extends Model
{
    use HasFactory;
    protected $table = 'supervisor';
}
