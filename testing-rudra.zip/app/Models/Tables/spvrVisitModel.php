<?php

namespace App\Models\Tables;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class spvrVisitModel extends Model
{
    use HasFactory;
    protected $table = 'supervisorvisithistory';
}
